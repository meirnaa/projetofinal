using Microsoft.EntityFrameworkCore;
using projetofinal.Models;
namespace projetofinal.Models
{
public class MyDbContext : DbContext
{
public MyDbContext(DbContextOptions<MyDbContext> options) :
base(options)
{
}
public DbSet<Marca> Marca {get; set;} //1
public DbSet<Produto> Produto { get; set; } //2
public DbSet<Item> Item { get; set; } //3
public DbSet<NotaDeVenda> NotaDeVenda { get; set; } //4
public DbSet<Cliente> Cliente { get; set; } //5
public DbSet<Vendedor> Vendedor { get; set; } //6
public DbSet<Transportadora> Transportadora { get; set; } //7
public DbSet<Pagamento> Pagamento { get; set; } //8
public DbSet<TipoDePagamento> TipoDePagamento { get; set; } //9
public DbSet<PagamentoComCheque> PagamentoComCheque { get; set; } //10
public DbSet<PagamentoComCartao> PagamentoComCartao { get; set; } //11

}
}